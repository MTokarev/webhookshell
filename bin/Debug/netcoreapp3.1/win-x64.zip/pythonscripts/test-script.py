#!/usr/bin/env python

print("Result from script test-script.py")
